namespace FrankBr.Engine;

/// <summary>
/// Contrato do estado central do canvas exposto à Engine.
/// Usa apenas tipos primitivos para manter a Engine independente da UI.
/// </summary>
public interface ICanvasModule : IEditorModule
{
    int DocumentWidth { get; }

    int DocumentHeight { get; }

    double DisplayScale { get; }

    double ZoomFactor { get; }

    double EffectiveZoom { get; }

    double PanX { get; }

    double PanY { get; }

    bool ShowGrid { get; }

    bool SnapToGrid { get; }

    double GridSize { get; }

    double PointerX { get; }

    double PointerY { get; }
}
