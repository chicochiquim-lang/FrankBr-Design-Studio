namespace FrankBr.Engine.Managers;

/// <summary>
/// Controla a identidade da ferramenta ativa sem depender de controles WPF.
/// </summary>
public sealed class ToolManager : IEditorModule
{
    public string Name => "Tools";

    public bool IsInitialized { get; private set; }

    public string ActiveToolId { get; private set; } = "select";

    public event EventHandler<string>? ActiveToolChanged;

    public void Initialize() => IsInitialized = true;

    public void Shutdown() => IsInitialized = false;

    public void Activate(string toolId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(toolId);

        var normalized = toolId.Trim().ToLowerInvariant();
        if (string.Equals(ActiveToolId, normalized, StringComparison.Ordinal))
            return;

        ActiveToolId = normalized;
        ActiveToolChanged?.Invoke(this, ActiveToolId);
    }
}
