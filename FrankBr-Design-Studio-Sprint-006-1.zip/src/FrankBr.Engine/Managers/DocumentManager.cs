namespace FrankBr.Engine.Managers;

/// <summary>
/// Estado mínimo do documento atual. Será expandido quando o formato .frank
/// e o sistema de páginas, camadas e objetos forem implementados.
/// </summary>
public sealed class DocumentManager : IEditorModule
{
    public string Name => "Documents";

    public bool IsInitialized { get; private set; }

    public string CurrentDocumentName { get; private set; } = "NovoProjeto.frank";

    public bool HasOpenDocument => IsInitialized;

    public void Initialize() => IsInitialized = true;

    public void Shutdown() => IsInitialized = false;

    public void RenameCurrentDocument(string name)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        CurrentDocumentName = name.Trim();
    }
}
