namespace FrankBr.Engine.Managers;

/// <summary>
/// Fachada da Engine para o módulo de canvas.
/// Recursos como zoom e pan serão adicionados gradualmente nos próximos FBs.
/// </summary>
public sealed class CanvasManager
{
    public CanvasManager(ICanvasModule module)
    {
        Module = module ?? throw new ArgumentNullException(nameof(module));
    }

    public ICanvasModule Module { get; }

    public int DocumentWidth => Module.DocumentWidth;

    public int DocumentHeight => Module.DocumentHeight;

    public double EffectiveZoom => Module.EffectiveZoom;

    public bool ShowGrid => Module.ShowGrid;

    public bool SnapToGrid => Module.SnapToGrid;
}
