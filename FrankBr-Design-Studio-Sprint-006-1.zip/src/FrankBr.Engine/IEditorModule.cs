namespace FrankBr.Engine;

/// <summary>
/// Contrato básico para módulos coordenados pelo EditorEngine.
/// A Engine não depende de WPF nem de uma interface gráfica específica.
/// </summary>
public interface IEditorModule
{
    string Name { get; }

    bool IsInitialized { get; }

    void Initialize();

    void Shutdown();
}
