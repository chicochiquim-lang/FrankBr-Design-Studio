using FrankBr.Engine.Managers;

namespace FrankBr.Engine;

/// <summary>
/// Ponto central de acesso aos módulos do editor.
/// Coordena o ciclo de vida sem conhecer WPF, janelas ou controles visuais.
/// </summary>
public sealed class EditorEngine : IDisposable
{
    private readonly List<IEditorModule> modules;
    private bool isDisposed;

    public EditorEngine(ICanvasModule canvasModule)
    {
        ArgumentNullException.ThrowIfNull(canvasModule);

        Canvas = new CanvasManager(canvasModule);
        Documents = new DocumentManager();
        Tools = new ToolManager();

        modules =
        [
            canvasModule,
            Documents,
            Tools
        ];
    }

    public CanvasManager Canvas { get; }

    public DocumentManager Documents { get; }

    public ToolManager Tools { get; }

    public bool IsInitialized { get; private set; }

    public IReadOnlyList<IEditorModule> Modules => modules;

    public void Initialize()
    {
        ObjectDisposedException.ThrowIf(isDisposed, this);

        if (IsInitialized)
            return;

        foreach (var module in modules)
            module.Initialize();

        IsInitialized = true;
    }

    public void Shutdown()
    {
        if (!IsInitialized)
            return;

        for (var index = modules.Count - 1; index >= 0; index--)
            modules[index].Shutdown();

        IsInitialized = false;
    }

    public void Dispose()
    {
        if (isDisposed)
            return;

        Shutdown();
        isDisposed = true;
    }
}
