using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using FrankBr.App.Models;
using FrankBr.App.Services;

namespace FrankBr.App.Controls;

public partial class FrankCanvas : UserControl
{
    private const double MinimumItemSize = 24;

    private readonly CanvasService fallbackCanvasService = new();
    private Point dragStart;
    private double itemStartX;
    private double itemStartY;
    private bool isDragging;
    private double resizeStartX;
    private double resizeStartY;
    private double resizeStartWidth;
    private double resizeStartHeight;
    private string resizeHandle = string.Empty;

    private bool isSpacePressed;
    private bool isLeftButtonPan;

    public FrankCanvas() => InitializeComponent();

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register(
            nameof(ItemsSource),
            typeof(IEnumerable),
            typeof(FrankCanvas),
            new PropertyMetadata(null));

    public static readonly DependencyProperty CanvasServiceProperty =
        DependencyProperty.Register(
            nameof(CanvasService),
            typeof(CanvasService),
            typeof(FrankCanvas),
            new PropertyMetadata(null, OnCanvasServiceChanged));

    public IEnumerable? ItemsSource
    {
        get => (IEnumerable?)GetValue(ItemsSourceProperty);
        set => SetValue(ItemsSourceProperty, value);
    }

    public CanvasService? CanvasService
    {
        get => (CanvasService?)GetValue(CanvasServiceProperty);
        set => SetValue(CanvasServiceProperty, value);
    }

    private CanvasService Service => CanvasService ?? fallbackCanvasService;

    private static void OnCanvasServiceChanged(
        DependencyObject dependencyObject,
        DependencyPropertyChangedEventArgs eventArgs)
    {
        var canvas = (FrankCanvas)dependencyObject;
        canvas.DocumentGridLayer.CanvasService = eventArgs.NewValue as CanvasService;
    }

    public CanvasImageItem? SelectedItem => Service.SelectedItem;

    public double DisplayWidth => DesignCanvas.Width;

    public double DisplayHeight => DesignCanvas.Height;

    public event EventHandler<CanvasSelectionChangedEventArgs>? SelectionChanged;

    public event EventHandler<CanvasPointerEventArgs>? PointerMoved;

    public event EventHandler<CanvasZoomChangedEventArgs>? ZoomChanged;

    public void SelectItem(CanvasImageItem? item)
    {
        Service.SelectItem(item, ItemsSource);
        RaiseSelectionChanged();
    }

    public void ZoomIn() => ApplyZoom(Service.Zoom.ZoomIn());

    public void ZoomOut() => ApplyZoom(Service.Zoom.ZoomOut());

    public void ResetZoom() => ApplyZoom(Service.Zoom.Reset());

    public void FitToScreen()
    {
        CanvasScrollViewer.UpdateLayout();

        var factor = Service.Zoom.CalculateFitFactor(
            CanvasScrollViewer.ViewportWidth,
            CanvasScrollViewer.ViewportHeight,
            DesignCanvas.Width,
            DesignCanvas.Height);

        ApplyZoom(factor);
        CenterDocument();
    }


    private void CanvasScrollViewer_PreviewMouseDown(
        object sender,
        MouseButtonEventArgs e)
    {
        var middleButtonPan = e.ChangedButton == MouseButton.Middle;
        var spaceLeftPan =
            isSpacePressed &&
            e.ChangedButton == MouseButton.Left;

        if (!middleButtonPan && !spaceLeftPan)
            return;

        CanvasScrollViewer.Focus();

        isLeftButtonPan = spaceLeftPan;

        Service.Pan.Begin(
            e.GetPosition(CanvasScrollViewer),
            CanvasScrollViewer.HorizontalOffset,
            CanvasScrollViewer.VerticalOffset);

        CanvasScrollViewer.CaptureMouse();
        Mouse.OverrideCursor = Cursors.Hand;

        e.Handled = true;
    }

    private void CanvasScrollViewer_PreviewMouseMove(
        object sender,
        MouseEventArgs e)
    {
        if (!Service.Pan.IsPanning)
            return;

        var correctButtonPressed =
            e.MiddleButton == MouseButtonState.Pressed ||
            (isLeftButtonPan &&
             e.LeftButton == MouseButtonState.Pressed);

        if (!correctButtonPressed)
        {
            EndPan();
            return;
        }

        var offsets = Service.Pan.Update(
            e.GetPosition(CanvasScrollViewer));

        CanvasScrollViewer.ScrollToHorizontalOffset(
            offsets.HorizontalOffset);

        CanvasScrollViewer.ScrollToVerticalOffset(
            offsets.VerticalOffset);

        e.Handled = true;
    }

    private void CanvasScrollViewer_PreviewMouseUp(
        object sender,
        MouseButtonEventArgs e)
    {
        if (!Service.Pan.IsPanning)
            return;

        var endsMiddlePan =
            !isLeftButtonPan &&
            e.ChangedButton == MouseButton.Middle;

        var endsSpacePan =
            isLeftButtonPan &&
            e.ChangedButton == MouseButton.Left;

        if (!endsMiddlePan && !endsSpacePan)
            return;

        EndPan();
        e.Handled = true;
    }

    private void CanvasScrollViewer_PreviewKeyDown(
        object sender,
        KeyEventArgs e)
    {
        if (e.Key != Key.Space)
            return;

        isSpacePressed = true;

        if (!Service.Pan.IsPanning)
            Mouse.OverrideCursor = Cursors.Hand;

        e.Handled = true;
    }

    private void CanvasScrollViewer_PreviewKeyUp(
        object sender,
        KeyEventArgs e)
    {
        if (e.Key != Key.Space)
            return;

        isSpacePressed = false;

        if (isLeftButtonPan && Service.Pan.IsPanning)
            EndPan();
        else if (!Service.Pan.IsPanning)
            Mouse.OverrideCursor = null;

        e.Handled = true;
    }

    private void EndPan()
    {
        Service.Pan.End();
        isLeftButtonPan = false;

        if (CanvasScrollViewer.IsMouseCaptured)
            CanvasScrollViewer.ReleaseMouseCapture();

        Mouse.OverrideCursor =
            isSpacePressed ? Cursors.Hand : null;
    }

    private void CanvasScrollViewer_PreviewMouseWheel(
        object sender,
        MouseWheelEventArgs e)
    {
        if (!Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
            return;

        var viewportPoint = e.GetPosition(CanvasScrollViewer);
        var canvasPoint = e.GetPosition(ZoomSurface);

        var factor = e.Delta > 0
            ? Service.Zoom.ZoomIn()
            : Service.Zoom.ZoomOut();

        ApplyZoom(factor);

        CanvasScrollViewer.UpdateLayout();
        CanvasScrollViewer.ScrollToHorizontalOffset(
            canvasPoint.X * factor - viewportPoint.X);

        CanvasScrollViewer.ScrollToVerticalOffset(
            canvasPoint.Y * factor - viewportPoint.Y);

        Service.Pan.Synchronize(
            CanvasScrollViewer.HorizontalOffset,
            CanvasScrollViewer.VerticalOffset);

        e.Handled = true;
    }

    private void ApplyZoom(double factor)
    {
        CanvasZoomTransform.ScaleX = factor;
        CanvasZoomTransform.ScaleY = factor;
        ZoomSurface.UpdateLayout();

        ZoomChanged?.Invoke(
            this,
            new CanvasZoomChangedEventArgs(
                factor,
                Service.EffectiveZoom));
    }

    private void CenterDocument()
    {
        CanvasScrollViewer.UpdateLayout();

        CanvasScrollViewer.ScrollToHorizontalOffset(
            Math.Max(
                0,
                (CanvasScrollViewer.ExtentWidth -
                 CanvasScrollViewer.ViewportWidth) / 2));

        CanvasScrollViewer.ScrollToVerticalOffset(
            Math.Max(
                0,
                (CanvasScrollViewer.ExtentHeight -
                 CanvasScrollViewer.ViewportHeight) / 2));

        Service.Pan.Synchronize(
            CanvasScrollViewer.HorizontalOffset,
            CanvasScrollViewer.VerticalOffset);
    }

    private void ImageItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not Border border || border.DataContext is not CanvasImageItem item)
            return;

        SelectItem(item);
        dragStart = e.GetPosition(DesignCanvas);
        itemStartX = item.X;
        itemStartY = item.Y;
        isDragging = true;
        border.CaptureMouse();
        e.Handled = true;
    }

    private void ImageItem_MouseMove(object sender, MouseEventArgs e)
    {
        var selectedItem = Service.SelectedItem;
        if (!isDragging || selectedItem is null || e.LeftButton != MouseButtonState.Pressed)
            return;

        var current = e.GetPosition(DesignCanvas);

        selectedItem.X = Math.Clamp(
            itemStartX + current.X - dragStart.X,
            0,
            Math.Max(0, DesignCanvas.Width - selectedItem.Width));

        selectedItem.Y = Math.Clamp(
            itemStartY + current.Y - dragStart.Y,
            0,
            Math.Max(0, DesignCanvas.Height - selectedItem.Height));

        RaiseSelectionChanged();
    }

    private void ImageItem_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        isDragging = false;

        if (sender is Border border)
            border.ReleaseMouseCapture();

        e.Handled = true;
    }

    private void ResizeHandle_DragStarted(object sender, DragStartedEventArgs e)
    {
        if (sender is not Thumb thumb || thumb.DataContext is not CanvasImageItem item)
            return;

        SelectItem(item);
        resizeHandle = thumb.Tag?.ToString() ?? string.Empty;
        resizeStartX = item.X;
        resizeStartY = item.Y;
        resizeStartWidth = item.Width;
        resizeStartHeight = item.Height;
        isDragging = false;
    }

    private void ResizeHandle_DragDelta(object sender, DragDeltaEventArgs e)
    {
        if (sender is not Thumb thumb || thumb.DataContext is not CanvasImageItem item)
            return;

        var left = resizeStartX;
        var top = resizeStartY;
        var right = resizeStartX + resizeStartWidth;
        var bottom = resizeStartY + resizeStartHeight;

        if (resizeHandle.Contains("Left"))
            left = Math.Clamp(resizeStartX + e.HorizontalChange, 0, right - MinimumItemSize);

        if (resizeHandle.Contains("Right"))
            right = Math.Clamp(
                resizeStartX + resizeStartWidth + e.HorizontalChange,
                left + MinimumItemSize,
                DesignCanvas.Width);

        if (resizeHandle.Contains("Top"))
            top = Math.Clamp(resizeStartY + e.VerticalChange, 0, bottom - MinimumItemSize);

        if (resizeHandle.Contains("Bottom"))
            bottom = Math.Clamp(
                resizeStartY + resizeStartHeight + e.VerticalChange,
                top + MinimumItemSize,
                DesignCanvas.Height);

        item.X = left;
        item.Y = top;
        item.Width = right - left;
        item.Height = bottom - top;
        RaiseSelectionChanged();
    }

    private void ResizeHandle_DragCompleted(object sender, DragCompletedEventArgs e)
    {
        resizeHandle = string.Empty;
        RaiseSelectionChanged();
    }

    private void DesignCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource == DesignCanvas)
            SelectItem(null);
    }

    private void DesignCanvas_MouseMove(object sender, MouseEventArgs e)
    {
        var point = e.GetPosition(DesignCanvas);
        Service.UpdatePointer(point.X, point.Y);

        PointerMoved?.Invoke(
            this,
            new CanvasPointerEventArgs(
                Service.State.PointerX,
                Service.State.PointerY));
    }

    private void RaiseSelectionChanged() =>
        SelectionChanged?.Invoke(
            this,
            new CanvasSelectionChangedEventArgs(Service.SelectedItem));
}

public sealed class CanvasSelectionChangedEventArgs(CanvasImageItem? selectedItem) : EventArgs
{
    public CanvasImageItem? SelectedItem { get; } = selectedItem;
}

public sealed class CanvasPointerEventArgs(double x, double y) : EventArgs
{
    public double X { get; } = x;

    public double Y { get; } = y;
}


public sealed class CanvasZoomChangedEventArgs(
    double zoomFactor,
    double effectiveZoom) : EventArgs
{
    public double ZoomFactor { get; } = zoomFactor;

    public double EffectiveZoom { get; } = effectiveZoom;
}
