using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using FrankBr.App.Services;

namespace FrankBr.App.Controls;

/// <summary>
/// Desenha a grade do documento em uma camada independente dos objetos.
/// </summary>
public sealed class GridLayer : FrameworkElement
{
    private const int MajorLineInterval = 4;

    public static readonly DependencyProperty CanvasServiceProperty =
        DependencyProperty.Register(
            nameof(CanvasService),
            typeof(CanvasService),
            typeof(GridLayer),
            new FrameworkPropertyMetadata(
                null,
                FrameworkPropertyMetadataOptions.AffectsRender,
                OnCanvasServiceChanged));

    public CanvasService? CanvasService
    {
        get => (CanvasService?)GetValue(CanvasServiceProperty);
        set => SetValue(CanvasServiceProperty, value);
    }

    protected override void OnRender(DrawingContext drawingContext)
    {
        base.OnRender(drawingContext);

        var state = CanvasService?.State;
        if (state is null || !state.ShowGrid)
            return;

        // A camada inteira é ampliada pelo ZoomSurface. Aqui usamos somente
        // a escala-base para evitar aplicar o ZoomFactor duas vezes.
        var spacing = state.GridSize * state.DisplayScale;
        if (spacing <= 0)
            return;

        // Evita excesso de linhas quando o zoom ficar muito baixo futuramente.
        var logicalMultiplier = 1;
        while (spacing * logicalMultiplier < 8)
            logicalMultiplier *= 2;

        spacing *= logicalMultiplier;

        var minorPen = CreatePen(Color.FromArgb(72, 82, 103, 132), 0.65);
        var majorPen = CreatePen(Color.FromArgb(125, 72, 102, 142), 1.0);

        var columns = (int)Math.Ceiling(ActualWidth / spacing);
        for (var column = 0; column <= columns; column++)
        {
            var x = Math.Round(column * spacing) + 0.5;
            var pen = column % MajorLineInterval == 0 ? majorPen : minorPen;
            drawingContext.DrawLine(pen, new Point(x, 0), new Point(x, ActualHeight));
        }

        var rows = (int)Math.Ceiling(ActualHeight / spacing);
        for (var row = 0; row <= rows; row++)
        {
            var y = Math.Round(row * spacing) + 0.5;
            var pen = row % MajorLineInterval == 0 ? majorPen : minorPen;
            drawingContext.DrawLine(pen, new Point(0, y), new Point(ActualWidth, y));
        }
    }

    private static Pen CreatePen(Color color, double thickness)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();

        var pen = new Pen(brush, thickness);
        pen.Freeze();
        return pen;
    }

    private static void OnCanvasServiceChanged(
        DependencyObject dependencyObject,
        DependencyPropertyChangedEventArgs eventArgs)
    {
        var layer = (GridLayer)dependencyObject;

        if (eventArgs.OldValue is CanvasService oldService)
            oldService.State.PropertyChanged -= layer.CanvasState_PropertyChanged;

        if (eventArgs.NewValue is CanvasService newService)
            newService.State.PropertyChanged += layer.CanvasState_PropertyChanged;

        layer.InvalidateVisual();
    }

    private void CanvasState_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(CanvasState.ShowGrid)
            or nameof(CanvasState.GridSize)
            or nameof(CanvasState.DisplayScale))
        {
            InvalidateVisual();
        }
    }
}
