using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace FrankBr.App.Services;

/// <summary>
/// Estado exclusivo da visualização do editor.
/// Não representa o documento nem altera a posição real dos objetos.
/// </summary>
public sealed class ViewportState : INotifyPropertyChanged
{
    private double zoomFactor = 1.0;
    private double horizontalOffset;
    private double verticalOffset;
    private bool isPanning;

    public double ZoomFactor
    {
        get => zoomFactor;
        set => SetField(ref zoomFactor, Math.Clamp(value, 0.25, 16.0));
    }

    public double HorizontalOffset
    {
        get => horizontalOffset;
        set => SetField(ref horizontalOffset, Math.Max(0, value));
    }

    public double VerticalOffset
    {
        get => verticalOffset;
        set => SetField(ref verticalOffset, Math.Max(0, value));
    }

    public bool IsPanning
    {
        get => isPanning;
        internal set => SetField(ref isPanning, value);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private bool SetField<T>(
        ref T field,
        T value,
        [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
            return false;

        field = value;
        PropertyChanged?.Invoke(
            this,
            new PropertyChangedEventArgs(propertyName));

        return true;
    }
}
