using System.ComponentModel;
using System.Runtime.CompilerServices;
using FrankBr.App.Models;

namespace FrankBr.App.Services;

public sealed class CanvasState : INotifyPropertyChanged
{
    private int documentWidth = 2048;
    private int documentHeight = 2048;
    private double displayScale = 0.35;
    private bool showGrid = true;
    private bool snapToGrid;
    private double gridSize = 64;
    private double pointerX;
    private double pointerY;
    private CanvasImageItem? selectedItem;

    public int DocumentWidth
    {
        get => documentWidth;
        set => SetField(ref documentWidth, Math.Max(1, value));
    }

    public int DocumentHeight
    {
        get => documentHeight;
        set => SetField(ref documentHeight, Math.Max(1, value));
    }

    public double DisplayScale
    {
        get => displayScale;
        set => SetField(
            ref displayScale,
            Math.Clamp(value, 0.01, 8.0));
    }


    public bool ShowGrid
    {
        get => showGrid;
        set => SetField(ref showGrid, value);
    }

    public bool SnapToGrid
    {
        get => snapToGrid;
        set => SetField(ref snapToGrid, value);
    }

    public double GridSize
    {
        get => gridSize;
        set => SetField(ref gridSize, Math.Max(1, value));
    }

    public double PointerX
    {
        get => pointerX;
        internal set => SetField(ref pointerX, value);
    }

    public double PointerY
    {
        get => pointerY;
        internal set => SetField(ref pointerY, value);
    }

    public CanvasImageItem? SelectedItem
    {
        get => selectedItem;
        internal set => SetField(ref selectedItem, value);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
            return false;

        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
