using System.Collections;
using FrankBr.App.Models;
using FrankBr.Engine;

namespace FrankBr.App.Services;

public sealed class CanvasService : ICanvasModule
{
    public CanvasService(
        CanvasState? state = null,
        ViewportState? viewport = null)
    {
        State = state ?? new CanvasState();
        Viewport = viewport ?? new ViewportState();

        Zoom = new ZoomService(Viewport, State);
        Pan = new PanService(Viewport);
    }

    public CanvasState State { get; }

    public ViewportState Viewport { get; }

    public ZoomService Zoom { get; }

    public PanService Pan { get; }

    public CanvasImageItem? SelectedItem => State.SelectedItem;


    public string Name => "Canvas";

    public bool IsInitialized { get; private set; }

    public int DocumentWidth => State.DocumentWidth;

    public int DocumentHeight => State.DocumentHeight;

    public double DisplayScale => State.DisplayScale;

    public double ZoomFactor => Viewport.ZoomFactor;

    public double EffectiveZoom => Zoom.EffectiveZoom;

    public double PanX => Viewport.HorizontalOffset;

    public double PanY => Viewport.VerticalOffset;

    public bool ShowGrid => State.ShowGrid;

    public bool SnapToGrid => State.SnapToGrid;

    public double GridSize => State.GridSize;

    public double PointerX => State.PointerX;

    public double PointerY => State.PointerY;

    public void Initialize() => IsInitialized = true;

    public void Shutdown() => IsInitialized = false;


    public void SelectItem(CanvasImageItem? item, IEnumerable? items)
    {
        if (items is not null)
        {
            foreach (var current in items)
            {
                if (current is CanvasImageItem image)
                    image.IsSelected = ReferenceEquals(image, item);
            }
        }

        State.SelectedItem = item;
    }

    public void ClearSelection(IEnumerable? items) => SelectItem(null, items);

    public void UpdatePointer(double displayX, double displayY)
    {
        var scale = State.DisplayScale;
        if (scale <= 0)
            scale = 1;

        State.PointerX = Math.Clamp(displayX / scale, 0, State.DocumentWidth);
        State.PointerY = Math.Clamp(displayY / scale, 0, State.DocumentHeight);
    }

    public double DisplayToDocument(double value)
    {
        var scale = State.DisplayScale;
        return scale <= 0 ? value : value / scale;
    }

    public double DocumentToDisplay(double value) => value * State.DisplayScale;
}
