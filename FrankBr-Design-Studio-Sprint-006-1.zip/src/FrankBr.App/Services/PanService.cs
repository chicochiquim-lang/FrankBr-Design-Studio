using System.Windows;

namespace FrankBr.App.Services;

/// <summary>
/// Controla o deslocamento da visualização sem alterar o documento.
/// </summary>
public sealed class PanService
{
    private readonly ViewportState viewport;

    public PanService(ViewportState viewport)
    {
        this.viewport =
            viewport ??
            throw new ArgumentNullException(nameof(viewport));
    }

    public bool IsPanning =>
        viewport.IsPanning;

    public Point StartPointer { get; private set; }

    public double StartHorizontalOffset { get; private set; }

    public double StartVerticalOffset { get; private set; }

    public void Begin(
        Point pointer,
        double horizontalOffset,
        double verticalOffset)
    {
        viewport.IsPanning = true;
        StartPointer = pointer;
        StartHorizontalOffset = horizontalOffset;
        StartVerticalOffset = verticalOffset;

        viewport.HorizontalOffset = horizontalOffset;
        viewport.VerticalOffset = verticalOffset;
    }

    public (
        double HorizontalOffset,
        double VerticalOffset) Update(Point pointer)
    {
        if (!viewport.IsPanning)
        {
            return (
                viewport.HorizontalOffset,
                viewport.VerticalOffset);
        }

        viewport.HorizontalOffset =
            StartHorizontalOffset -
            (pointer.X - StartPointer.X);

        viewport.VerticalOffset =
            StartVerticalOffset -
            (pointer.Y - StartPointer.Y);

        return (
            viewport.HorizontalOffset,
            viewport.VerticalOffset);
    }

    public void Synchronize(
        double horizontalOffset,
        double verticalOffset)
    {
        viewport.HorizontalOffset = horizontalOffset;
        viewport.VerticalOffset = verticalOffset;
    }

    public void End()
    {
        viewport.IsPanning = false;
    }
}
