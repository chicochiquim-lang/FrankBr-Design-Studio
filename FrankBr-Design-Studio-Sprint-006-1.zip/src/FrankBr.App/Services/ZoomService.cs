using System.Windows;

namespace FrankBr.App.Services;

/// <summary>
/// Controla os limites, níveis e conversões do zoom do editor.
/// O fator 1.0 representa a visualização-base definida pelo CanvasState.
/// </summary>
public sealed class ZoomService
{
    public const double MinimumFactor = 0.25;
    public const double MaximumFactor = 16.0;
    public const double DefaultStep = 1.15;

    private readonly ViewportState viewport;
    private readonly CanvasState canvas;

    public ZoomService(
        ViewportState viewport,
        CanvasState canvas)
    {
        this.viewport =
            viewport ??
            throw new ArgumentNullException(nameof(viewport));

        this.canvas =
            canvas ??
            throw new ArgumentNullException(nameof(canvas));
    }

    public double Factor => viewport.ZoomFactor;

    public double EffectiveZoom =>
        canvas.DisplayScale * viewport.ZoomFactor;

    public bool CanZoomIn => Factor < MaximumFactor;

    public bool CanZoomOut => Factor > MinimumFactor;

    public double ZoomIn() =>
        SetZoom(Factor * DefaultStep);

    public double ZoomOut() =>
        SetZoom(Factor / DefaultStep);

    public double Reset() =>
        SetZoom(1.0);

    public double SetZoom(double factor)
    {
        viewport.ZoomFactor = Math.Clamp(
            factor,
            MinimumFactor,
            MaximumFactor);

        return viewport.ZoomFactor;
    }

    public double CalculateFitFactor(
        double viewportWidth,
        double viewportHeight,
        double contentWidth,
        double contentHeight,
        double margin = 28)
    {
        if (viewportWidth <= 0 ||
            viewportHeight <= 0 ||
            contentWidth <= 0 ||
            contentHeight <= 0)
        {
            return Factor;
        }

        var availableWidth =
            Math.Max(1, viewportWidth - margin * 2);

        var availableHeight =
            Math.Max(1, viewportHeight - margin * 2);

        return Math.Clamp(
            Math.Min(
                availableWidth / contentWidth,
                availableHeight / contentHeight),
            MinimumFactor,
            MaximumFactor);
    }

    public Point ScreenToCanvas(Point screenPoint) =>
        new(
            screenPoint.X /
            Math.Max(Factor, MinimumFactor),
            screenPoint.Y /
            Math.Max(Factor, MinimumFactor));

    public Point CanvasToScreen(Point canvasPoint) =>
        new(
            canvasPoint.X * Factor,
            canvasPoint.Y * Factor);
}
