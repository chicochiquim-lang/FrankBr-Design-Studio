using System.Collections.ObjectModel;
using FrankBr.App.Models;
using FrankBr.App.Services;

namespace FrankBr.App.ViewModels;

public sealed class MainWindowViewModel
{
    public MainWindowViewModel(CanvasService canvasService)
    {
        CanvasService = canvasService;
    }

    public string ProductName => "FrankBr Design Studio";

    public string Slogan => "Design sem limites para simuladores e projetos gráficos.";

    public CanvasService CanvasService { get; }

    public CanvasState Canvas => CanvasService.State;

    public ObservableCollection<CanvasImageItem> Images { get; } = [];

    public string ProjectFileName => "NovoProjeto.frankbr";

    public string ResolutionText =>
        $"Canvas: {Canvas.DocumentWidth} × {Canvas.DocumentHeight}px";

    public string ZoomText => $"Zoom: {CanvasService.EffectiveZoom:P0}";
}
