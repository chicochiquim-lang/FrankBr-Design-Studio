using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using FrankBr.App.Controls;
using FrankBr.App.Models;
using FrankBr.App.Services;
using FrankBr.App.ViewModels;
using FrankBr.Engine;
using Microsoft.Win32;

namespace FrankBr.App;

public partial class MainWindow : Window
{
    private readonly EditorEngine editorEngine;
    private readonly CanvasService canvasService;
    private readonly MainWindowViewModel viewModel;

    public MainWindow()
    {
        canvasService = new CanvasService();
        editorEngine = new EditorEngine(canvasService);
        editorEngine.Initialize();
        viewModel = new MainWindowViewModel(canvasService);

        InitializeComponent();
        DataContext = viewModel;
        EditorCanvas.CanvasService = canvasService;
    }

    private void ImportImage_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Imagens (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp",
            Multiselect = true
        };

        if (dialog.ShowDialog() != true)
            return;

        foreach (var path in dialog.FileNames)
        {
            try
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.UriSource = new Uri(path, UriKind.Absolute);
                bitmap.EndInit();
                bitmap.Freeze();

                const double maxDisplaySize = 420;
                var scale = Math.Min(
                    1.0,
                    maxDisplaySize / Math.Max(bitmap.PixelWidth, bitmap.PixelHeight));

                var width = Math.Max(
                    30,
                    bitmap.PixelWidth * scale * canvasService.State.DisplayScale);

                var height = Math.Max(
                    30,
                    bitmap.PixelHeight * scale * canvasService.State.DisplayScale);

                var item = new CanvasImageItem
                {
                    Name = Path.GetFileNameWithoutExtension(path),
                    SourcePath = path,
                    Source = bitmap,
                    Width = width,
                    Height = height,
                    X = Math.Max(
                        0,
                        (EditorCanvas.DisplayWidth - width) / 2 + viewModel.Images.Count * 16),
                    Y = Math.Max(
                        0,
                        (EditorCanvas.DisplayHeight - height) / 2 + viewModel.Images.Count * 16)
                };

                viewModel.Images.Add(item);
                EditorCanvas.SelectItem(item);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Não foi possível importar a imagem.\n{ex.Message}",
                    "FrankBr Design Studio",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }
    }

    private void EditorCanvas_SelectionChanged(
        object? sender,
        CanvasSelectionChangedEventArgs e)
    {
        UpdateSelectionText();
    }

    private void EditorCanvas_PointerMoved(
        object? sender,
        CanvasPointerEventArgs e)
    {
        MouseXText.Text = $"X: {e.X:0}";
        MouseYText.Text = $"Y: {e.Y:0}";
    }


    private void ZoomIn_Click(object sender, RoutedEventArgs e) =>
        EditorCanvas.ZoomIn();

    private void ZoomOut_Click(object sender, RoutedEventArgs e) =>
        EditorCanvas.ZoomOut();

    private void ZoomReset_Click(object sender, RoutedEventArgs e) =>
        EditorCanvas.ResetZoom();

    private void ZoomFit_Click(object sender, RoutedEventArgs e) =>
        EditorCanvas.FitToScreen();

    private void EditorCanvas_ZoomChanged(
        object? sender,
        CanvasZoomChangedEventArgs e)
    {
        var zoomText = $"{e.EffectiveZoom:P0}";
        ToolbarZoomText.Text = zoomText;
        StatusZoomText.Text = $"Zoom: {zoomText}";
    }

    private void Layers_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (sender is ListBox listBox && listBox.SelectedItem is CanvasImageItem item)
            EditorCanvas.SelectItem(item);
    }

    private void GridToggleButton_Click(object sender, RoutedEventArgs e)
    {
        SetGridVisibility(!canvasService.State.ShowGrid);
    }

    private void GridMenuItem_Click(object sender, RoutedEventArgs e)
    {
        SetGridVisibility(GridMenuItem.IsChecked);
    }

    private void SetGridVisibility(bool isVisible)
    {
        canvasService.State.ShowGrid = isVisible;
        GridMenuItem.IsChecked = isVisible;
        GridToggleButton.Content = isVisible ? "Grade: ligada" : "Grade: desligada";
    }

    private void DeleteSelected_Click(object sender, RoutedEventArgs e) => DeleteSelected();

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Delete)
        {
            DeleteSelected();
            e.Handled = true;
        }
        else if (e.Key == Key.I && Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            ImportImage_Click(sender, e);
            e.Handled = true;
        }
        else if (e.Key == Key.OemPlus &&
                 Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            EditorCanvas.ZoomIn();
            e.Handled = true;
        }
        else if (e.Key == Key.OemMinus &&
                 Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            EditorCanvas.ZoomOut();
            e.Handled = true;
        }
        else if (e.Key == Key.D0 &&
                 Keyboard.Modifiers == ModifierKeys.Control)
        {
            EditorCanvas.ResetZoom();
            e.Handled = true;
        }
        else if (e.Key == Key.D0 &&
                 Keyboard.Modifiers.HasFlag(ModifierKeys.Control) &&
                 Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
        {
            EditorCanvas.FitToScreen();
            e.Handled = true;
        }
    }

    private void DeleteSelected()
    {
        if (canvasService.SelectedItem is null)
            return;

        viewModel.Images.Remove(canvasService.SelectedItem);
        EditorCanvas.SelectItem(null);
    }

    private void UpdateSelectionText()
    {
        var selectedItem = canvasService.SelectedItem;

        if (selectedItem is null)
        {
            SelectionNameText.Text = "Nenhum objeto selecionado";
            SelectionPositionText.Text =
                $"Canvas: {canvasService.State.DocumentWidth} × " +
                $"{canvasService.State.DocumentHeight} px";
            return;
        }

        SelectionNameText.Text = selectedItem.Name;
        SelectionPositionText.Text =
            $"X: {canvasService.DisplayToDocument(selectedItem.X):0}  " +
            $"Y: {canvasService.DisplayToDocument(selectedItem.Y):0}\n" +
            $"Tamanho: {canvasService.DisplayToDocument(selectedItem.Width):0} × " +
            $"{canvasService.DisplayToDocument(selectedItem.Height):0} px";
    }

    protected override void OnClosed(EventArgs e)
    {
        editorEngine.Dispose();
        base.OnClosed(e);
    }

    private void Exit_Click(object sender, RoutedEventArgs e) => Close();
}
